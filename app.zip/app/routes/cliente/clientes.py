from flask import render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

from app import app, db
from app.models import Cliente, Agendamento, Servico
from datetime import datetime

@app.route("/cliente/cadastro", methods=["GET", "POST"])
def cadastro_cliente():
    if request.method == "POST":
        nome = request.form["nome"]
        if len(nome.strip()) < 3:
            flash(
                "Informe um nome válido",
                "danger"
            )
            return redirect(
                url_for("cadastro_cliente")
            )
        telefone = request.form["telefone"]
        email = request.form["email"]
        cliente_existente = Cliente.query.filter_by(
            email=email
        ).first()
        if cliente_existente:
            flash( 
                "Já existe uma conta cadastrada com este e-mail",
                "danger"
            )
            return redirect(
                url_for("cadastro_cliente")
            )
        senha = request.form["senha"]
        if len(senha) < 6:
            flash(
                "A senha deve possuir pelo menos 6 caracteres.",
                "danger"
            )
            return redirect(
                url_for("cadastro_cliente")
            )
        senha = generate_password_hash(senha)

        cliente = Cliente(
            nome=nome,
            telefone=telefone,
            email=email,
            senha=senha
        )
        db.session.add(cliente)
        db.session.commit()

        flash(
            "Cadastro realizado com sucesso!",
            "success"
        )
        return redirect(
            url_for("login_cliente")
        )
    return render_template(
        "site/cadastro_cliente.html"
    )

@app.route("/cliente/login", methods=["GET", "POST"])
def login_cliente():
    if request.method == "POST":
        email = request.form["email"]
        senha = request.form["senha"]
        cliente = Cliente.query.filter_by(
            email=email
        ).first()

        if cliente and check_password_hash(
            cliente.senha,
            senha
        ):
            session["cliente_id"] = cliente.id
            session["cliente_nome"] = cliente.nome
            return redirect(
                url_for("painel_cliente")
            )
        flash(
            "E-mail ou senha inválidos.",
            "danger"
        )

    return render_template(
        "site/login_cliente.html"
    )

@app.route("/cliente/painel")
def painel_cliente():
    if "cliente_id" not in session:
        return redirect(
            url_for("login_cliente")
        )
    cliente = db.seesion.get(
        cliente,
        session["cliente_id"]
    )
    return render_template(
        "site/painel_cliente.html",
        cliente=cliente
    )

@app.route("/cliente/agendar", methods=["GET", "POST"])
def agendar_cliente():
    if "cliente_id" not in session:
        return redirect(url_for("login_cliente"))

    servicos = Servico.query.all()

    if request.method == "POST":
        servico_id = request.form["servico"]
        data = request.form["data"]
        horario = request.form["horario"]
        data = datetime.strptime(
            data,
            "%Y-%m-%d"
        ).date()

        novo_agendamento = Agendamento(
            cliente_id=session["cliente_id"],
            servico_id=servico_id,
            data=data,
            horario=horario,
            status="pendente"
        )

        db.session.add(novo_agendamento)
        db.session.commit()

        flash(
            "Agendamento realizado com sucesso!",
            "success"
        )
        return redirect(
            url_for("painel_cliente")
        )
    return render_template(
        "site/agendar_cliente.html",
        servicos=servicos
    )

@app.route("/cliente/logout")
def logout_cliente():
    session.clear()
    return redirect(
        url_for("login_cliente")
    )