from flask import render_template, redirect, url_for, session
from app import app
from app.models import Cliente, Servico, Agendamento
from datetime import date 

@app.route("/dashboard")
def dashboard():
    if "usuario" not in session:
        return redirect(url_for("login"))
    total_clientes = Cliente.query.count()
    total_servicos = Servico.query.count()
    agendamentos_hoje = Agendamento.query.filter_by(
        data=date.today(),
        status="agendado"
    ).count()
    pendentes = Agendamento.query.filter_by(
        status="agendado"
    ).count()

    receita_hoje = 0
    
    agendamentos = Agendamento.query.filter_by(
        data=date.today(),
        status="agendado"
    ).all()

    for ag in agendamentos:
        receita_hoje += ag.servico.preco

    return render_template(
        "dashboard.html",
        total_clientes=total_clientes,
        total_servicos=total_servicos,
        agendamentos_hoje=agendamentos_hoje,
        pendentes=pendentes,
        receita_hoje=receita_hoje
    )
