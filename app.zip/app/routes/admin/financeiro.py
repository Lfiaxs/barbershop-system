from flask import render_template, session, redirect, url_for
from app import app
from app.models import Agendamento
from datetime import date

@app.route("/financeiro")
def financeiro():
    if "usuario" not in session:
        return redirect(url_for("login"))
    atendimentos = Agendamento.query.filter_by(
        status="concluido"
    ).order_by(
        Agendamento.data.desc()
    ).all()

    total = 0
    receita_hoje = 0
    receita_mes = 0

    hoje = date.today()
    quantidade = len(atendimentos)

    for atendimento in atendimentos:
        valor = atendimento.servico.preco
        total += valor
        if atendimento.data == hoje:
            receita_hoje += valor
        if (
            atendimento.data.month == hoje.month and
            atendimento.data.year == hoje.year
        ):
            receita_mes += valor
    ticket_medio = 0

    if quantidade > 0:
        ticket_medio = total / quantidade

    dias = []
    valores = []

    for atendimento in atendimentos:
        dias.append(
            atendimento.data.strftime("%d/%m")
        )
        valores.append(
            atendimento.servico.preco
        )
    return render_template(
        "financeiro.html",
        atendimentos=atendimentos,
        total=total,
        receita_hoje=receita_hoje,
        receita_mes=receita_mes,
        quantidade=quantidade,
        ticket_medio=ticket_medio,
        dias=dias,
        valores=valores
    )